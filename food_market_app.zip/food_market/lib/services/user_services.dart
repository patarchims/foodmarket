part of 'services.dart';

class UserServices {
  // Method yang akan di kirimkan ke backend,

  static Future<ApiReturnValue<User>> signIn(
    String email,
    String password,
  ) async {
    // Membuat simulasi
    await Future.delayed(Duration(milliseconds: 500));

    return ApiReturnValue(value: mockUser);
    // return ApiReturnValue(message: "Wrong email or password");
  }
}
