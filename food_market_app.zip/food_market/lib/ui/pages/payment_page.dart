part of 'pages.dart';

class PaymentPage extends StatefulWidget {
  final Transaction transaction;

  PaymentPage({this.transaction});

  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    // Digunakan saat proses login
    // bool isLoading = false;

    return GeneralPage(
      title: "Payment",
      subtitle: "You deserve better meal",
      onBackButtonPressed: () {},
      backColor: 'FAFAFC'.toColor(),
      child: Column(
        children: [
          // Content Here
          // TOP Content
          Container(
            margin: EdgeInsets.only(bottom: defaultMargin),
            padding:
                EdgeInsets.symmetric(horizontal: defaultMargin, vertical: 16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Item Ordered", style: blackFontStyle2),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Parent(
                        style: ParentStyle()
                          ..margin(top: 12, right: 12)
                          ..width(60)
                          ..height(60)
                          ..background.image(
                              url: widget.transaction.food.picturePath,
                              fit: BoxFit.cover)
                          ..borderRadius(all: 8)),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width -
                              2 * defaultMargin -
                              72 -
                              78,
                          child: Text(widget.transaction.food.name,
                              maxLines: 1,
                              overflow: TextOverflow.clip,
                              style: blackFontStyle2),
                        ),
                        Text(
                          NumberFormat.currency(
                                  locale: 'id-ID',
                                  symbol: 'IDR ',
                                  decimalDigits: 0)
                              .format(widget.transaction.food.price),
                          style: greyFontStyle.copyWith(fontSize: 13),
                        )
                      ],
                    ),
                    Text('${widget.transaction.quantity}  items(s)',
                        style: greyFontStyle.copyWith(fontSize: 13),
                        textAlign: TextAlign.right)
                  ],
                ),

                // Detail Transaction Here
                Padding(
                    padding: EdgeInsets.only(top: 16, bottom: 8),
                    child: Text("Details Transaction",
                        style: blackFontStyle3.copyWith(fontSize: 13))),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(widget.transaction.food.name,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(
                            NumberFormat.currency(
                                    locale: 'id-ID',
                                    symbol: 'IDR ',
                                    decimalDigits: 0)
                                .format(widget.transaction.total),
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle3.copyWith(fontSize: 14)))
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text('Driver',
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(
                            NumberFormat.currency(
                                    locale: 'id-ID',
                                    symbol: 'IDR ',
                                    decimalDigits: 0)
                                .format(50000),
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle3.copyWith(fontSize: 14)))
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text('Tax 10%',
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(
                            NumberFormat.currency(
                                    locale: 'id-ID',
                                    symbol: 'IDR ',
                                    decimalDigits: 0)
                                .format(widget.transaction.food.price *
                                    widget.transaction.quantity *
                                    0.1),
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle3.copyWith(fontSize: 14)))
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text('Total Price',
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(
                            NumberFormat.currency(
                                    locale: 'id-ID',
                                    symbol: 'IDR ',
                                    decimalDigits: 0)
                                .format(widget.transaction.total * 1.1 + 50000),
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle2.copyWith(
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                                color: '1ABC9C'.toColor())))
                  ],
                ),

                SizedBox(height: 32 + defaultMargin),

                // Deliver to :
                Padding(
                    padding: EdgeInsets.only(top: 16, bottom: 8),
                    child: Text("Deliver to:",
                        style: blackFontStyle3.copyWith(fontSize: 13))),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text("Name",
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(widget.transaction.user.name,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle3.copyWith(fontSize: 14)))
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text('Phone No.',
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(widget.transaction.user.phoneNumber,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle3.copyWith(fontSize: 14)))
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text('Address',
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(widget.transaction.user.address,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle3.copyWith(fontSize: 14)))
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text('House No.',
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(widget.transaction.user.houseNumber,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle2.copyWith(
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                            )))
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Price Here
                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text('City',
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            style: greyFontStyle.copyWith(fontSize: 14))),

                    SizedBox(
                        width: MediaQuery.of(context).size.width / 2 -
                            5 -
                            defaultMargin,
                        child: Text(widget.transaction.user.city,
                            overflow: TextOverflow.clip,
                            maxLines: 1,
                            textAlign: TextAlign.right,
                            style: blackFontStyle2.copyWith(
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                            )))
                  ],
                ),

                // Button Cek Out
                (isLoading)
                    ? Center(
                        child: loadingIndicator,
                      )
                    : Container(
                        width: double.infinity,
                        margin: EdgeInsets.only(top: defaultMargin),
                        height: 45,
                        child: isLoading
                            ? SpinKitFadingCircle(
                                size: 45,
                                color: mainColor,
                              )
                            : RaisedButton(
                                onPressed: () async {
                                  //
                                  setState(() {
                                    isLoading = true;
                                  });

                                  bool result = await context
                                      .bloc<TransactionCubit>()
                                      .submitTransaction(widget.transaction
                                          .copyWith(
                                              dateTime: DateTime.now(),
                                              total: (widget.transaction.total *
                                                          1.1)
                                                      .toInt() +
                                                  50000));

                                  if (result == true) {
                                    Get.to(SuccessOrderPage());
                                  } else {
                                    setState(() {
                                      // set State
                                      isLoading = false;
                                    });

                                    notificationMessage('Transactions Failed',
                                        'Please try again later');
                                  }
                                },
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                color: mainColor,
                                child: Text(
                                  "Checkout Now",
                                  style: blackFontStyle2,
                                ),
                              ),
                      ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
