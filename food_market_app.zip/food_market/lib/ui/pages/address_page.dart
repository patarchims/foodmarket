part of 'pages.dart';

class AddressPage extends StatefulWidget {
  @override
  _AddressPageState createState() => _AddressPageState();
}

class _AddressPageState extends State<AddressPage> {
  @override
  Widget build(BuildContext context) {
    /* Input textfield   */

    TextEditingController phoneNumberController = TextEditingController();
    TextEditingController addressConttroller = TextEditingController();
    TextEditingController hoseNumberConttroller = TextEditingController();

    // Digunakan saat proses login
    bool isLoading = false;

    return GeneralPage(
      title: 'Address',
      subtitle: 'Make sure it’s valid',
      onBackButtonPressed: () {
        // Navigation Back
        Get.back();
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Text Email Address
          textLabel(defaultMargin, 26, defaultMargin, 6, "Phone No."),

          // Input Text Full Name
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: defaultMargin),
            padding: EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.black),
            ),
            child: TextField(
              controller: phoneNumberController,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: "Type your full name",
                  hintStyle: greyFontStyle),
            ),
          ),

          // Text Email Address
          textLabel(defaultMargin, 26, defaultMargin, 6, "Address"),

          // Input Text Email Address
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: defaultMargin),
            padding: EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.black),
            ),
            child: TextField(
              controller: addressConttroller,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: "Type your address",
                  hintStyle: greyFontStyle),
            ),
          ),

          // Text Password
          textLabel(defaultMargin, 16, defaultMargin, 6, "House No."),

          // Input Text Password
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: defaultMargin),
            padding: EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.black),
            ),
            child: TextField(
              controller: hoseNumberConttroller,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: "Type your house number",
                  hintStyle: greyFontStyle),
            ),
          ),

          // Text City
          textLabel(defaultMargin, 16, defaultMargin, 6, "City"),

          // Input Text Password
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: defaultMargin),
            padding: EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.black),
            ),
            child: DropdownButton(
                isExpanded: true,
                underline: SizedBox(),
                items: [
                  DropdownMenuItem(
                      child: Text(
                    "Bandung",
                    style: blackFontStyle3,
                  )),
                  DropdownMenuItem(
                      child: Text(
                    "Jakarta",
                    style: blackFontStyle3,
                  )),
                  DropdownMenuItem(
                      child: Text(
                    "Bali",
                    style: blackFontStyle3,
                  )),
                ],
                onChanged: (items) {}),
          ),

          // Button Continue
          Container(
            width: double.infinity,
            margin: EdgeInsets.only(top: defaultMargin),
            height: 45,
            padding: EdgeInsets.symmetric(horizontal: defaultMargin),
            child: isLoading
                ? SpinKitFadingCircle(
                    size: 45,
                    color: mainColor,
                  )
                : RaisedButton(
                    onPressed: () {},
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    color: mainColor,
                    child: Text(
                      "Sign Up Now",
                      style: blackFontStyle2,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
