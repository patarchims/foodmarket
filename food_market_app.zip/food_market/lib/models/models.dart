import 'package:equatable/equatable.dart';

part 'food_model.dart';
part 'transaction_models.dart';
part 'user_model.dart';
part 'api_return_value.dart';
