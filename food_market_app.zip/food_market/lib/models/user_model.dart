part of 'models.dart';

class User extends Equatable {
  final int id;
  final String name,
      email,
      address,
      houseNumber,
      phoneNumber,
      city,
      picturePatch;

  User(
      {this.id,
      this.name,
      this.email,
      this.address,
      this.houseNumber,
      this.phoneNumber,
      this.city,
      this.picturePatch});

  @override
  List<Object> get props =>
      [id, name, email, address, houseNumber, phoneNumber, city, picturePatch];
}

User mockUser = User(
    id: 1,
    name: "Patar Chims",
    email: "patarchims@gmail.com",
    address: "Jalan Bandung",
    picturePatch:
        "https://avatars2.githubusercontent.com/u/50953777?s=400&u=6cb342d8686da8a69a560ff7d88a519209ffd50c&v=4",
    city: "Pematangsiantar",
    houseNumber: "45",
    phoneNumber: "081366204109");
