package com.example.food_market

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
